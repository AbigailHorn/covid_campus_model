# code for creating multiple parameter draws from a distribution to represent the uncertainty in the parameters

replicates <- 100

########## create sample values from the uncertainty
R0_student_to_student <- rnorm(replicates,
                               mean=p_tab$Value[which(p_tab$Var=="R0_student_to_student")],
                               sd=calcStDevFromLowerUpper(mean=p_tab$Value[which(p_tab$Var=="R0_student_to_student")],
                                                          lower=p_tab$Lower[which(p_tab$Var=="R0_student_to_student")],
                                                          upper=p_tab$Upper[which(p_tab$Var=="R0_student_to_student")]))
R0_on_to_on <- rnorm(replicates,
                     mean=p_tab$Value[which(p_tab$Var=="R0_on_to_on")],
                     sd=calcStDevFromLowerUpper(mean=p_tab$Value[which(p_tab$Var=="R0_on_to_on")],
                                                lower=p_tab$Lower[which(p_tab$Var=="R0_on_to_on")],
                                                upper=p_tab$Upper[which(p_tab$Var=="R0_on_to_on")]))
R0_saf <- rnorm(replicates,
                mean=p_tab$Value[which(p_tab$Var=="R0_saf")],
                sd=calcStDevFromLowerUpper(mean=p_tab$Value[which(p_tab$Var=="R0_saf")],
                                           lower=p_tab$Lower[which(p_tab$Var=="R0_saf")],
                                           upper=p_tab$Upper[which(p_tab$Var=="R0_saf")]))

beta_student_to_student <- as.numeric(R0_student_to_student/infectious/(N_on+N_off)) # daily effective contact rates
beta_on_to_on <- as.numeric((R0_student_to_student + R0_on_to_on) / infectious / N_on)                                           
beta_saf <- as.numeric(R0_saf/infectious/(N_on+N_off+N_saf))  

# sensitivity <- 
sensitivity_on <- rnorm(replicates,
                        mean=p_tab$Value[which(p_tab$Var=="sensitivity_on")],
                        sd=calcStDevFromLowerUpper(mean=p_tab$Value[which(p_tab$Var=="sensitivity_on")],
                                                   lower=p_tab$Lower[which(p_tab$Var=="sensitivity_on")],
                                                   upper=p_tab$Upper[which(p_tab$Var=="sensitivity_on")]))
sensitivity <- rnorm(replicates,
                     mean=p_tab$Value[which(p_tab$Var=="sensitivity")],
                     sd=calcStDevFromLowerUpper(mean=p_tab$Value[which(p_tab$Var=="sensitivity")],
                                                lower=p_tab$Lower[which(p_tab$Var=="sensitivity")],
                                                upper=p_tab$Upper[which(p_tab$Var=="sensitivity")]))
sensitivity_saf <- rnorm(replicates,
                         mean=p_tab$Value[which(p_tab$Var=="sensitivity_saf")],
                         sd=calcStDevFromLowerUpper(mean=p_tab$Value[which(p_tab$Var=="sensitivity_saf")],
                                                    lower=p_tab$Lower[which(p_tab$Var=="sensitivity_saf")],
                                                    upper=p_tab$Upper[which(p_tab$Var=="sensitivity_saf")]))

# screening 
screening_on <- rnorm(replicates,
                      mean=p_tab$Value[which(p_tab$Var=="screening_on")],
                      sd=calcStDevFromLowerUpper(mean=p_tab$Value[which(p_tab$Var=="screening_on")],
                                                 lower=p_tab$Lower[which(p_tab$Var=="screening_on")],
                                                 upper=p_tab$Upper[which(p_tab$Var=="screening_on")]))
screening <- rnorm(replicates,
                   mean=p_tab$Value[which(p_tab$Var=="screening")],
                   sd=calcStDevFromLowerUpper(mean=p_tab$Value[which(p_tab$Var=="screening")],
                                              lower=p_tab$Lower[which(p_tab$Var=="screening")],
                                              upper=p_tab$Upper[which(p_tab$Var=="screening")]))
screening_saf <- rnorm(replicates,
                       mean=p_tab$Value[which(p_tab$Var=="screening_saf")],
                       sd=calcStDevFromLowerUpper(mean=p_tab$Value[which(p_tab$Var=="screening_saf")],
                                                  lower=p_tab$Lower[which(p_tab$Var=="screening_saf")],
                                                  upper=p_tab$Upper[which(p_tab$Var=="screening_saf")]))

# testing 
testing <- rnorm(replicates,
                 mean=p_tab$Value[which(p_tab$Var=="testing")],
                 sd=calcStDevFromLowerUpper(mean=p_tab$Value[which(p_tab$Var=="testing")],
                                            lower=p_tab$Lower[which(p_tab$Var=="testing")],
                                            upper=p_tab$Upper[which(p_tab$Var=="testing")]))

