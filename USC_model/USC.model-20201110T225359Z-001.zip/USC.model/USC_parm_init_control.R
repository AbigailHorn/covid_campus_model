
calcStDevFromLowerUpper <- function(mean=mean, lower=lower, upper=upper, CI=.95) {
    z.stat <- qnorm((CI + (1-CI)/2))
    se.u <- (upper-mean)/z.stat
    se.l <- (mean-lower)/z.stat
    mean(c(se.u, se.l))
}


#parameter_table <- read.csv("99_ParameterTable_s.csv") # Parameter table manuscript
parameter_table <-read.csv("ParameterTable_USC_Spring.csv")   # Parameter table spring
p_tab <- parameter_table[,1:9]
p_tab$Value <-gsub(",","",p_tab$Value)
p_tab$Value <- as.numeric(as.character(p_tab$Value))
p_tab$Lower <- as.numeric(as.character(p_tab$Lower))
p_tab$Upper <- as.numeric(as.character(p_tab$Upper))

#Epi parameters
R0_student_to_student <- p_tab$Value[which(p_tab$Var=="R0_student_to_student")]   # number of other students that a student infects, on average
R0_on_to_on <- p_tab$Value[which(p_tab$Var == "R0_on_to_on")]                     # number of additional students that a student living off campus infects, on average
R0_saf <- p_tab$Value[which(p_tab$Var == "R0_saf")]                               # number of staff and faculty that an average student infects

latent <- p_tab$Value[which(p_tab$Var == "latent")]                               # latent period duration in days.  This is shorter than incubation period, which is more like 5 days
infectious <- p_tab$Value[which(p_tab$Var == "infectious")]  


N_on <- p_tab$Value[which(p_tab$Var == "N_on")]

N_off<-p_tab$Value[which(p_tab$Var == "N_off")]           #Based on number on campus

N_saf <- p_tab$Value[which(p_tab$Var == "N_saf")]

N = N_on + N_off + N_saf


beta_student_to_student <- as.numeric(R0_student_to_student/infectious/(N_on+N_off)) # daily effective contact rates
beta_on_to_on <- as.numeric((R0_student_to_student + R0_on_to_on) / infectious / N_on)                                           
beta_saf <- as.numeric(R0_saf/infectious/(N_on+N_off+N_saf))  
                    # infectious period in days.This is longer than symptomatic period, which is more like 6 days.
                                                                                  # Effectively this assumes that infectiousness starts 1 day before symptoms

#beta_student_to_student <- R0_student_to_student/infectious                       # daily effective contact rate -- symptomatic period
#beta_on_to_on <- R0_on_to_on/infectious                                           # daily effective contact rate -- symptomatic period
#beta_saf <- R0_saf/infectious  
# daily effective contact rate -- symptomatic period
eff_npi <- p_tab$Value[which(p_tab$Var == "eff_npi")]                             # efficacy of masking and other NPIs

daily_new_case <- p_tab$Value[which(p_tab$Var == "daily_new_case")]               # daily new case/population in surrounding area 
under_report <- p_tab$Value[which(p_tab$Var == "under_report")]                   # under-report factor

community <- daily_new_case*under_report                                          # daily probability of community infection - not acquired on campus

p_asympt_stu <- 1-p_tab$Value[which(p_tab$Var == "p_sympt_stu")]                  # proportion asymptomatic -- students
p_hosp_stu <- p_tab$Value[which(p_tab$Var == "p_hosp_stu")]                       # probability of hospitalization -- students
p_death_stu <- p_tab$Value[which(p_tab$Var == "p_death_stu")]                     # probability of death -- students

p_asympt_saf <- 1-p_tab$Value[which(p_tab$Var == "p_sympt_saf")]                  # proportion asymptomatic -- staff and faculty
p_hosp_saf <- p_tab$Value[which(p_tab$Var == "p_hosp_saf")]                       # probability of hospitalization -- staff and faculty
p_death_saf <- p_tab$Value[which(p_tab$Var == "p_death_saf")]                     # probability of death -- staff and faculty

contacts <- p_tab$Value[which(p_tab$Var == "contacts")]                           # contacts per case
p_contacts_reached <- p_tab$Value[which(p_tab$Var == "p_contacts_reached")]       # proportion of contacts reached
ili <- p_tab$Value[which(p_tab$Var == "ili")]                                     # daily ili
sensitivity  <- p_tab$Value[which(p_tab$Var == "sensitivity")]                    # PCR sensitivity on day 4
sensitivity_on  <- p_tab$Value[which(p_tab$Var == "sensitivity_on")]                # PCR sensitivity on day 2
sensitivity_saf  <- p_tab$Value[which(p_tab$Var == "sensitivity_saf")]                # PCR sensitivity on day 7

isolation <- p_tab$Value[which(p_tab$Var == "isolation")]                         # isolation or quarantine period in days



# current population
E_on=0                      #students living on campus
I_on=0
P_on = 0
R_on = 0
Q_on = 0

E_off=0                     #students living off campus
I_off=0
P_off = 0
R_off = 0
Q_off = 0

E_saf=0
I_saf=0
P_saf = 0
R_saf = 0
Q_saf = 0


testing <- p_tab$Value[which(p_tab$Var == "testing")]
screening_on <- p_tab$Value[which(p_tab$Var == "screening_on")] #screening interval for oncampus students
screening <- p_tab$Value[which(p_tab$Var == "screening")] #screening intervals for off campus students and staff
screening_saf <- p_tab$Value[which(p_tab$Var == "screening_saf")] #screening intervals for staff and faculty
semesterDays <-  p_tab$Value[which(p_tab$Var == "SemesterDays")]

#testing=0
#screening_on=0              #screening interval for oncampus students
#screening =0             #screening intervals for off campus students and staff

## Initial conditions to model
init <- init.dcm(S_on=N_on-(E_on+I_on+R_on),        # number initially susceptible
                 E_on=E_on,                         # number initially incubating
                 I_on=I_on,                         # number initially infectious
                 Isym_on = 0,
                 P_on=P_on,                         # number initially isolated
                 R_on=R_on,                         # initially immune
                 Icum_on = 0,                       # cumulative cases -- for counting incidence
                 Pcum_on = 0,
                 Q_on = Q_on,
                 Qcum_on = 0,
                 Hcum_on =0,
                 Dcum_on=0,
                 Icum_on_camp=0,
                 #Icum_on_com=0,

                 S_off=N_off-(E_off+I_off+R_off),
                 E_off=E_off,
                 I_off=I_off,
                 Isym_off = 0,
                 P_off=P_off,
                 R_off=R_off,
                 Icum_off = 0,
                 Pcum_off = 0,
                 Q_off = Q_off,
                 Qcum_off = 0,
                 Hcum_off = 0,
                 Dcum_off =0,
                 Icum_off_camp=0,
                 #Icum_off_com=0,

                 S_saf=N_saf-(E_saf+I_saf+R_saf),
                 E_saf=E_saf,
                 I_saf=I_saf,
                 Isym_saf = 0,
                 P_saf=P_saf,
                 R_saf=R_saf,
                 Icum_saf = 0,
                 Pcum_saf = 0,
                 Q_saf = 0,
                 Hcum_saf =0,
                 Dcum_saf =0,
                 Icum_saf_camp=0,
                 #Icum_saf_com=0,

                 Test = 0,
                 lam_on = 0,
                 lam_off = 0,
                 lam_saf = 0
                 )

# Control features
#control <- control.dcm(nsteps = 116, new.mod = model)  #Time steps for manuscript
control <- control.dcm(nsteps = semesterDays, new.mod = model)    #Time steps for spring semester
